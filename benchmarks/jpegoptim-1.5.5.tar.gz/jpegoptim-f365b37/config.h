/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in
 *
 */


/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* The number of bytes in an int.  */
#define SIZEOF_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 8

/* Define if you have the getopt_long function.  */
#define HAVE_GETOPT_LONG 1

/* Define if you have mkstemps function. */
#define HAVE_MKSTEMPS 1

/* Define if you have labs function. */
#define HAVE_LABS 1

/* Define if you have the fileno function. */
#define HAVE_FILENO 1

/* Define if you have the utimensat function. */
#define HAVE_UTIMENSAT 1

/* Define if you have the fork function. */
#define HAVE_FORK 1

/* Define if you have the wait function. */
#define HAVE_WAIT 1

/* Define to 1 if `st_mtim' is a member of `struct stat'. */
#define HAVE_STRUCT_STAT_ST_MTIM 1

/* Define if you have the <getopt.h> header file.  */
#define HAVE_GETOPT_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <libgen.h> header file.  */
#define HAVE_LIBGEN_H 1

/* Define if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the <sys/wait.h> header file. */
#define HAVE_SYS_WAIT_H 1

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the jpeg library (-ljpeg).  */
#define HAVE_LIBJPEG 1

/* Define if jpeg library supports Arithmetic coding */
/* #undef HAVE_ARITH_CODE */

/* Define if jpeg library supports the MozJPEG extension setting JINT_DC_SCAN_OPT_MODE */
/* #undef HAVE_JINT_DC_SCAN_OPT_MODE */


/* Define if you have broken jmorecfg.h (SGI's usually have this problem) */
/* #undef BROKEN_METHODDEF */

#define HOST_TYPE "x86_64-pc-linux-gnu"


/* eof */
